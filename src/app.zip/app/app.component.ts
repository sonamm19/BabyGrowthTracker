import { Message } from "@angular/compiler/src/i18n/i18n_ast";
import { Component } from "@angular/core";
import { GrowthChart } from "./growthChart.component";

@Component({

    selector: 'pm-root',
    template: `<h1>{{Title}}</h1>
    <growth-chart></growth-chart>`
})


export class AppComponent {
    Title: string = "Welcome to my first page";
    name: string = "";
    //growthChart: GrowthChart = new GrowthChart();



}