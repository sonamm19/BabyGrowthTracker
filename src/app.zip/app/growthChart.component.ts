import { DecimalPipe } from "@angular/common";
import { Component, Input, OnInit } from "@angular/core";
import { WeightPercentileCacheService } from "./app.weightPercentileCache.service";
import * as XLSX from 'xlsx';
import { HttpClient } from '@angular/common/http';


@Component({

    selector: 'growth-chart',
    templateUrl: './growthChart.component.html',
    providers: [WeightPercentileCacheService]
})


export class GrowthChart implements OnInit {

    public selectedValue: any;
    categoryTypes: any;

    childName: string = "";
    gender: string = "";
    dateOfBirth: Date = new Date();
    dateOfMeasurement: Date | undefined;
    weight: DecimalPipe | undefined;
    selectedWeightUnit: any;
    height: DecimalPipe | undefined;
    selectedHeightUnit: any;
    headCircum: DecimalPipe | undefined;
    seletedHeadCircumUnit: any;
    submitted: boolean = false;
    message: string = "";
    weightUnitMatric: any;
    heightUnitMatric: any;
    headCircumUnitMatric: any;
    monthBasedPercentile: any;
    growthChart: GrowthChart = {} as GrowthChart;
    filePath: string = "";
    percentileResult: number = 0;
    percentileResultDescription: string | undefined;
    constructor(private weightPercentileCacheService: WeightPercentileCacheService, private httpClient: HttpClient) {
        console.log("inside constructor");
    }

    ngOnInit(): void {

        this.growthChart = new GrowthChart(this.weightPercentileCacheService, this.httpClient);
        this.growthChart.gender = "Male";
        this.growthChart.weightUnitMatric = WeighUnitItems;
        this.growthChart.selectedWeightUnit = this.growthChart.weightUnitMatric[0];
        this.growthChart.heightUnitMatric = VolumeUnitItems;
        this.growthChart.selectedHeightUnit = this.growthChart.heightUnitMatric[0];
        this.growthChart.headCircumUnitMatric = VolumeUnitItems;
        this.growthChart.seletedHeadCircumUnit = this.growthChart.headCircumUnitMatric[0];
    }

    Submit(login: any) {

        if (login.valid) {
            this.message = "Valid";
            this.submitted = login.submitted;
            var ageInMonth = this.calculateMonthfromDOB(this.growthChart.dateOfBirth);
            this.readExcelSheet(this.growthChart.gender, ageInMonth);
            console.log(this.calculateMonthfromDOB(this.growthChart.dateOfBirth));
        }
    }


    GetClosetpercentile(weight: any, arr: number[]) {

        if (arr === undefined || arr.length == 0) {
            return 0;
        }
        const output = arr.reduce((prev: number, curr: number) => Math.abs(curr - weight) < Math.abs(prev - weight) ? curr : prev);

        return output;
    }


    findPercentile(percentileValues: any) {

        if (percentileValues === undefined)
            return false;

        let arrayValues = [];
        for (var key in percentileValues) {
            if (key.startsWith("P")) {
                arrayValues.push(percentileValues[key]);
            }
        }
        var valueItem = this.GetClosetpercentile(this.growthChart.weight, arrayValues);
        var keyItem = Object.keys(percentileValues).find(key => percentileValues[key] === valueItem);
        this.percentileResult = parseInt(keyItem?.toString().replace('P', '')!);

        if (this.percentileResult > 85) {
            this.percentileResultDescription = "It seems that your child's weight may be too high, please consult with your doctor"
        }
        else if (this.percentileResult < 15) {
            this.percentileResultDescription = "It seems that your child's weight may be too low, please consult with your doctor"
        }


        return true;
    }

    calculateMonthfromDOB(birthdate: Date) {
        var month = new Date().getMonth() - new Date(birthdate).getMonth() + (12 * (new Date().getFullYear() - new Date(birthdate).getFullYear()));
        return Math.abs(month);
    }

    readExcelSheet(gender: string, month: number) {
        if (gender === 'Male') {
            this.filePath = 'assets/BoysPercentile.xlsx';
        }
        else {
            this.filePath = 'assets/GirlsPercentile.xlsx';
        }
        this.httpClient.get(this.filePath, { responseType: 'blob' })
            .subscribe((data: any) => {
                const reader: FileReader = new FileReader();
                let dataJson1;

                reader.onload = (e: any) => {
                    const bstr: string = e.target.result;
                    const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

                    /* grab first sheet */
                    const wsname1: string = wb.SheetNames[0];
                    const ws1: XLSX.WorkSheet = wb.Sheets[wsname1];

                    /* save data */
                    dataJson1 = XLSX.utils.sheet_to_json(ws1);
                    this.monthBasedPercentile = dataJson1[month];

                    console.log("monthBasedPercentile in function");
                    console.log(this.monthBasedPercentile);
                };
                reader.readAsBinaryString(data);
            });
    }
}

export const WeighUnitItems = [
    { Id: 1, DisplayValue: 'lb' },
    { Id: 2, DisplayValue: 'kg' }

];

export const VolumeUnitItems = [
    { Id: 1, DisplayValue: 'cm' },
    { Id: 2, DisplayValue: 'inch' }
]

export const filePathWeightPercentileBoys: string = "WHO_Boys_Percentile_0_5y";
export const filePathWeightPercentileGirls: string = "WHO_Girls_Percentile_0_5y";